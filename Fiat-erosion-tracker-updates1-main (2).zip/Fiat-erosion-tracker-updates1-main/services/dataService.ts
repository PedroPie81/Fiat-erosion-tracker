
// Bitcoin data services removed to focus on fiat and asset erosion metrics.
export {};
